Welcome to Polloloco Origin Minecraft Server.

To successfully play on the server, please put all of these .jar files in your minecraft mods folder.

You should download Fabric Loader for Minecraft 1.19.2